-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.5.35-0+wheezy1-log - (Debian)
-- Server OS:                    debian-linux-gnu
-- HeidiSQL Version:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping data for table diveboard.blog_categories: ~36 rows (approximately)
/*!40000 ALTER TABLE `blog_categories` DISABLE KEYS */;
REPLACE INTO `blog_categories` (`id`, `name`, `blob`, `created_at`, `updated_at`) VALUES
	(1, 'Blogroll', 'blogroll', '2012-11-06 08:55:58', '2012-11-06 08:55:58'),
	(2, 'Divers', 'divers', '2012-11-06 08:56:00', '2012-11-06 08:56:00'),
	(3, 'Spots', 'spots', '2012-11-06 08:56:03', '2012-11-06 08:56:03'),
	(4, 'Events', 'events', '2012-11-06 08:56:03', '2012-11-06 08:56:03'),
	(5, 'Sea Life', 'sea-life', '2012-11-06 08:56:04', '2012-11-06 08:56:04'),
	(6, 'Discover', 'discover', '2012-11-06 08:56:05', '2012-11-06 08:56:05'),
	(7, 'News', 'news', '2012-11-06 08:56:11', '2012-11-06 08:56:11'),
	(8, 'Technique', 'technics', '2012-11-06 08:56:15', '2012-11-06 08:56:15'),
	(9, 'diving', 'diving', '2012-11-06 08:56:17', '2012-11-06 08:56:17'),
	(10, 'coral', 'coral', '2012-11-06 08:56:30', '2012-11-06 08:56:30'),
	(11, 'Uncategorized', 'uncategorized', '2012-11-06 08:56:51', '2012-11-06 08:56:51'),
	(12, 'fish', 'fish', '2012-11-06 08:57:06', '2012-11-06 08:57:06'),
	(13, 'aquarium', 'aquarium', '2012-11-06 08:57:33', '2012-11-06 08:57:33'),
	(14, 'scuba', 'scuba', '2012-11-06 08:57:34', '2012-11-06 08:57:34'),
	(15, 'thailand', 'thailand', '2012-11-06 08:57:36', '2012-11-06 08:57:36'),
	(16, 'Gear', 'gear', '2012-11-06 08:57:38', '2012-11-06 08:57:38'),
	(17, 'paris', 'paris', '2012-11-06 08:58:32', '2012-11-06 08:58:32'),
	(18, 'species', 'species', '2012-11-06 08:58:39', '2012-11-06 08:58:39'),
	(19, 'Random thoughts', 'random_thoughts', '2012-11-06 13:42:03', '2012-11-06 13:42:03'),
	(20, 'Logbook', 'logbook', '2012-11-19 13:52:58', '2012-11-19 13:52:58'),
	(21, 'Question', 'question', '2012-11-22 08:43:19', '2012-11-22 08:43:19'),
	(22, 'Dive Shop', 'dive-shop', '2013-03-16 19:40:23', '2013-03-16 19:40:23'),
	(23, 'Education', 'education', '2013-06-24 15:32:10', '2013-06-24 15:32:10'),
	(24, 'UK Wrecks', 'uk-wrecks', '2013-07-31 12:32:28', '2013-07-31 12:32:28'),
	(25, 'Conservation', 'conservation', '2013-09-23 09:24:19', '2013-09-23 09:24:19'),
	(26, 'Dive Doodles', 'dive-doodles', '2013-10-20 17:42:18', '2013-10-20 17:42:18'),
	(27, 'Travel', 'travel', '2013-10-28 09:34:24', '2013-10-28 09:34:24'),
	(28, 'Photography', 'photography', '2013-11-25 13:05:18', '2013-11-25 13:05:18'),
	(29, 'Video', 'video', '2014-02-08 15:58:48', '2014-02-08 15:58:48'),
	(30, 'National Park', 'national-park', '2014-03-24 23:47:12', '2014-03-24 23:47:12'),
	(31, 'places in Venezuela', 'places-in-venezuela', '2014-04-14 00:41:59', '2014-04-14 00:41:59'),
	(32, 'Sailing', 'sailing', '2015-01-30 15:54:12', '2015-01-30 15:54:12'),
	(33, 'Services', 'services', '2015-05-16 08:01:12', '2015-05-16 08:01:12'),
	(34, 'Diveboard site issue', 'diveboard-site-issue', '2015-09-01 11:05:15', '2015-09-01 11:05:15'),
	(35, 'Live Aboard', 'live-aboard', '2015-11-01 12:58:20', '2015-11-01 12:58:20'),
	(36, 'Training', 'training', '2015-11-09 14:33:40', '2015-11-09 14:33:40');
/*!40000 ALTER TABLE `blog_categories` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
